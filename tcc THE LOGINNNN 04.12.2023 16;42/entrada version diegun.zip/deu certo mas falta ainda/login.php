<?php

 

require('conexao.php');

if(
   isset( $_GET['acao'])&&
   $_GET['acao'] == 'logout'
){
   unset($_SESSION['usuario']);
}

if(
   isset($_POST['usu_email'])&&
   isset($_POST['usu_password'])
   ){ 

    $email= $_POST['usu_email'];
    $senha= $_POST['usu_password'];

    $query = "SELECT * FROM users
       WHERE
         usu_email = '$email' AND
         usu_password = '$senha'
      ";

      $usuario = mysqli_query($con,$query);

      if( !$usuario ) {
         $erro = 'Login falhou.
          Verifique os dados.';

      }
      else{
         $_SESSION['usuario'] =
           mysqli_fetch_assoc($usuario);

           header('Location: aula.php');
           exit;

      }
}



 
 ?>
 
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
 <meta name="viewport" content="width=device-width, initial-scale=1">


 <h1>Login</h1>
 <a href= "novo.php" >Criar conta</a>

 <form action="aula.php" method = "POST">

 
  E-mail:
  <input type="email" name="usu_email">
  <br><br>
  Senha:
  <input type="password" name="usu_password">
  <br><br>

  

  <button type="submit">Entrar</button>
 
</form>
 
<?php
   if(isset($status)) {
           if ($status) {
              echo'OK! Cadastro salvo.';
           }else{
             echo 'Problema ao cadastrar.';
           }
   }
 
   if (isset ($enviado) && $enviado ) {

      echo '<img src="fotos/' . $filename . '"width"100">';
   }