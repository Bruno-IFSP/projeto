 
 <?php
 include('protect.php');

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
<meta name="viewport" content="width=device-width, initial-scale=1">
    <title>CRUD PHP MySQL</title>
</head>
 
<body>
    
</body>
</html>


<header>
        <nav>
            <a href="../professor.phpl#hero"><img src="../assetss/logo.png"></a>
            <ul> 
             <li> bem-vindo   <?= $_SESSION ['nomeprofessor'] ?>    </li><li><h1>|</h1></li>
           
                <li><a href=" ">inicio</a></li>
                <li><a href="#beneficios">Beneficios</a></li>
                <li><a href="#materias">Materias</a></li>
                <li><a href="#conheca">Sobre o site</a></li>
                <li><a href="../contato.html">Contato</a></li>
                <li><a class=text-white href="../aluno ou prof.html">Logout</a></li>
            </ul>
            <div class="menu">&#9776;</div>
        </nav>
    </header>